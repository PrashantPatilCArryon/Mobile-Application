<!DOCTYPE html>
<!-- saved from url=(0053)http://ionicframework.com/docs/api/directive/ionTabs/ -->
<html lang="en"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="description" content="Ionic makes it incredibly easy to build beautiful and interactive mobile apps using HTML5 and AngularJS.">
<meta name="keywords" content="html5,javascript,mobile,drifty,ionic,hybrid,phonegap,cordova,native,ios,android,angularjs">
<meta name="author" content="Drifty">
<meta property="og:image" content="http://ionicframework.com/img/ionic-logo-blog.png">


    

    <title>ion-tabs - Directive in module ionic -  Ionic Framework</title>
    <link href="./main123_files/site.css" rel="stylesheet">
<!--<script src="//cdn.optimizely.com/js/595530035.js"></script>-->
<script id="facebook-jssdk" src="./main123_files/all.js"></script><script id="twitter-wjs" src="./main123_files/widgets.js"></script><script async="" src="./main123_files/analytics.js"></script><script type="text/javascript">var _sf_startpt=(new Date()).getTime()</script>

<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-44023830-1', 'ionicframework.com');
  ga('send', 'pageview');

</script>


<script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0],p=/^http:/.test(d.location)?'http':'https';if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src=p+'://platform.twitter.com/widgets.js';fjs.parentNode.insertBefore(js,fjs);}}(document, 'script', 'twitter-wjs');</script>
<script src="./main123_files/jquery.min.js"></script>

  <style type="text/css">.fb_hidden{position:absolute;top:-10000px;z-index:10001}.fb_reposition{overflow:hidden;position:relative}.fb_invisible{display:none}.fb_reset{background:none;border:0;border-spacing:0;color:#000;cursor:auto;direction:ltr;font-family:"lucida grande", tahoma, verdana, arial, sans-serif;font-size:11px;font-style:normal;font-variant:normal;font-weight:normal;letter-spacing:normal;line-height:1;margin:0;overflow:visible;padding:0;text-align:left;text-decoration:none;text-indent:0;text-shadow:none;text-transform:none;visibility:visible;white-space:normal;word-spacing:normal}.fb_reset>div{overflow:hidden}.fb_link img{border:none}@keyframes fb_transform{from{opacity:0;transform:scale(.95)}to{opacity:1;transform:scale(1)}}.fb_animate{animation:fb_transform .3s forwards}
.fb_dialog{background:rgba(82, 82, 82, .7);position:absolute;top:-10000px;z-index:10001}.fb_reset .fb_dialog_legacy{overflow:visible}.fb_dialog_advanced{padding:10px;-moz-border-radius:8px;-webkit-border-radius:8px;border-radius:8px}.fb_dialog_content{background:#fff;color:#333}.fb_dialog_close_icon{background:url(https://fbstatic-a.akamaihd.net/rsrc.php/v2/yq/r/IE9JII6Z1Ys.png) no-repeat scroll 0 0 transparent;_background-image:url(https://fbstatic-a.akamaihd.net/rsrc.php/v2/yL/r/s816eWC-2sl.gif);cursor:pointer;display:block;height:15px;position:absolute;right:18px;top:17px;width:15px}.fb_dialog_mobile .fb_dialog_close_icon{top:5px;left:5px;right:auto}.fb_dialog_padding{background-color:transparent;position:absolute;width:1px;z-index:-1}.fb_dialog_close_icon:hover{background:url(https://fbstatic-a.akamaihd.net/rsrc.php/v2/yq/r/IE9JII6Z1Ys.png) no-repeat scroll 0 -15px transparent;_background-image:url(https://fbstatic-a.akamaihd.net/rsrc.php/v2/yL/r/s816eWC-2sl.gif)}.fb_dialog_close_icon:active{background:url(https://fbstatic-a.akamaihd.net/rsrc.php/v2/yq/r/IE9JII6Z1Ys.png) no-repeat scroll 0 -30px transparent;_background-image:url(https://fbstatic-a.akamaihd.net/rsrc.php/v2/yL/r/s816eWC-2sl.gif)}.fb_dialog_loader{background-color:#f6f7f9;border:1px solid #606060;font-size:24px;padding:20px}.fb_dialog_top_left,.fb_dialog_top_right,.fb_dialog_bottom_left,.fb_dialog_bottom_right{height:10px;width:10px;overflow:hidden;position:absolute}.fb_dialog_top_left{background:url(https://fbstatic-a.akamaihd.net/rsrc.php/v2/ye/r/8YeTNIlTZjm.png) no-repeat 0 0;left:-10px;top:-10px}.fb_dialog_top_right{background:url(https://fbstatic-a.akamaihd.net/rsrc.php/v2/ye/r/8YeTNIlTZjm.png) no-repeat 0 -10px;right:-10px;top:-10px}.fb_dialog_bottom_left{background:url(https://fbstatic-a.akamaihd.net/rsrc.php/v2/ye/r/8YeTNIlTZjm.png) no-repeat 0 -20px;bottom:-10px;left:-10px}.fb_dialog_bottom_right{background:url(https://fbstatic-a.akamaihd.net/rsrc.php/v2/ye/r/8YeTNIlTZjm.png) no-repeat 0 -30px;right:-10px;bottom:-10px}.fb_dialog_vert_left,.fb_dialog_vert_right,.fb_dialog_horiz_top,.fb_dialog_horiz_bottom{position:absolute;background:#525252;filter:alpha(opacity=70);opacity:.7}.fb_dialog_vert_left,.fb_dialog_vert_right{width:10px;height:100%}.fb_dialog_vert_left{margin-left:-10px}.fb_dialog_vert_right{right:0;margin-right:-10px}.fb_dialog_horiz_top,.fb_dialog_horiz_bottom{width:100%;height:10px}.fb_dialog_horiz_top{margin-top:-10px}.fb_dialog_horiz_bottom{bottom:0;margin-bottom:-10px}.fb_dialog_iframe{line-height:0}.fb_dialog_content .dialog_title{background:#6d84b4;border:1px solid #365899;color:#fff;font-size:14px;font-weight:bold;margin:0}.fb_dialog_content .dialog_title>span{background:url(https://fbstatic-a.akamaihd.net/rsrc.php/v2/yd/r/Cou7n-nqK52.gif) no-repeat 5px 50%;float:left;padding:5px 0 7px 26px}body.fb_hidden{-webkit-transform:none;height:100%;margin:0;overflow:visible;position:absolute;top:-10000px;left:0;width:100%}.fb_dialog.fb_dialog_mobile.loading{background:url(https://fbstatic-a.akamaihd.net/rsrc.php/v2/ya/r/3rhSv5V8j3o.gif) white no-repeat 50% 50%;min-height:100%;min-width:100%;overflow:hidden;position:absolute;top:0;z-index:10001}.fb_dialog.fb_dialog_mobile.loading.centered{width:auto;height:auto;min-height:initial;min-width:initial;background:none}.fb_dialog.fb_dialog_mobile.loading.centered #fb_dialog_loader_spinner{width:100%}.fb_dialog.fb_dialog_mobile.loading.centered .fb_dialog_content{background:none}.loading.centered #fb_dialog_loader_close{color:#fff;display:block;padding-top:20px;clear:both;font-size:18px}#fb-root #fb_dialog_ipad_overlay{background:rgba(0, 0, 0, .45);position:absolute;bottom:0;left:0;right:0;top:0;width:100%;min-height:100%;z-index:10000}#fb-root #fb_dialog_ipad_overlay.hidden{display:none}.fb_dialog.fb_dialog_mobile.loading iframe{visibility:hidden}.fb_dialog_content .dialog_header{-webkit-box-shadow:white 0 1px 1px -1px inset;background:-webkit-gradient(linear, 0% 0%, 0% 100%, from(#738ABA), to(#2C4987));border-bottom:1px solid;border-color:#1d4088;color:#fff;font:14px Helvetica, sans-serif;font-weight:bold;text-overflow:ellipsis;text-shadow:rgba(0, 30, 84, .296875) 0 -1px 0;vertical-align:middle;white-space:nowrap}.fb_dialog_content .dialog_header table{-webkit-font-smoothing:subpixel-antialiased;height:43px;width:100%}.fb_dialog_content .dialog_header td.header_left{font-size:12px;padding-left:5px;vertical-align:middle;width:60px}.fb_dialog_content .dialog_header td.header_right{font-size:12px;padding-right:5px;vertical-align:middle;width:60px}.fb_dialog_content .touchable_button{background:-webkit-gradient(linear, 0% 0%, 0% 100%, from(#4966A6), color-stop(.5, #355492), to(#2A4887));border:1px solid #29487d;-webkit-background-clip:padding-box;-webkit-border-radius:3px;-webkit-box-shadow:rgba(0, 0, 0, .117188) 0 1px 1px inset, rgba(255, 255, 255, .167969) 0 1px 0;display:inline-block;margin-top:3px;max-width:85px;line-height:18px;padding:4px 12px;position:relative}.fb_dialog_content .dialog_header .touchable_button input{border:none;background:none;color:#fff;font:12px Helvetica, sans-serif;font-weight:bold;margin:2px -12px;padding:2px 6px 3px 6px;text-shadow:rgba(0, 30, 84, .296875) 0 -1px 0}.fb_dialog_content .dialog_header .header_center{color:#fff;font-size:16px;font-weight:bold;line-height:18px;text-align:center;vertical-align:middle}.fb_dialog_content .dialog_content{background:url(https://fbstatic-a.akamaihd.net/rsrc.php/v2/y9/r/jKEcVPZFk-2.gif) no-repeat 50% 50%;border:1px solid #555;border-bottom:0;border-top:0;height:150px}.fb_dialog_content .dialog_footer{background:#f6f7f9;border:1px solid #555;border-top-color:#ccc;height:40px}#fb_dialog_loader_close{float:left}.fb_dialog.fb_dialog_mobile .fb_dialog_close_button{text-shadow:rgba(0, 30, 84, .296875) 0 -1px 0}.fb_dialog.fb_dialog_mobile .fb_dialog_close_icon{visibility:hidden}#fb_dialog_loader_spinner{animation:rotateSpinner 1.2s linear infinite;background-color:transparent;background-image:url(https://fbstatic-a.akamaihd.net/rsrc.php/v2/yD/r/t-wz8gw1xG1.png);background-repeat:no-repeat;background-position:50% 50%;height:24px;width:24px}@keyframes rotateSpinner{0%{transform:rotate(0deg)}100%{transform:rotate(360deg)}}
.fb_iframe_widget{display:inline-block;position:relative}.fb_iframe_widget span{display:inline-block;position:relative;text-align:justify}.fb_iframe_widget iframe{position:absolute}.fb_iframe_widget_fluid_desktop,.fb_iframe_widget_fluid_desktop span,.fb_iframe_widget_fluid_desktop iframe{max-width:100%}.fb_iframe_widget_fluid_desktop iframe{min-width:220px;position:relative}.fb_iframe_widget_lift{z-index:1}.fb_hide_iframes iframe{position:relative;left:-10000px}.fb_iframe_widget_loader{position:relative;display:inline-block}.fb_iframe_widget_fluid{display:inline}.fb_iframe_widget_fluid span{width:100%}.fb_iframe_widget_loader iframe{min-height:32px;z-index:2;zoom:1}.fb_iframe_widget_loader .FB_Loader{background:url(https://fbstatic-a.akamaihd.net/rsrc.php/v2/y9/r/jKEcVPZFk-2.gif) no-repeat;height:32px;width:32px;margin-left:-16px;position:absolute;left:50%;z-index:4}</style></head>

  <body class="docs docs-page docs-api">

    <nav class="navbar navbar-default horizontal-gradient" role="navigation">
  <div class="container">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle button ionic" data-toggle="collapse" data-target=".navbar-ex1-collapse">
        <i class="icon ion-navicon"></i>
      </button>
      <a class="navbar-brand" href="http://ionicframework.com/">
        
          <img src="./main123_files/ionic-logo-white.svg" width="123" height="43" alt="Ionic Framework">
        
      </a>
      <a href="http://blog.ionic.io/announcing-ionic-1-3/" target="_blank" class="paper-tag">
      <img src="./main123_files/1-3-note.png" alt="Ionic 1.3 is out!" width="28" height="32">
      </a>
      <a href="http://ionicframework.com/docs/v2" class="beta-tag">
      <img src="./main123_files/beta-tag.png" alt="2 beta is out!" width="31" height="31">
      </a>
    </div>

    <div class="collapse navbar-collapse navbar-ex1-collapse">
      <ul class="nav navbar-nav navbar-right">
        <li><a class="getting-started-nav nav-link" href="http://ionicframework.com/getting-started/">Getting Started</a></li>
        <li><a class="docs-nav nav-link" href="http://ionicframework.com/docs/">Docs</a></li>
        <li class="hide-sm"><a class="nav-link" href="https://forum.ionicframework.com/?utm_source=framework&amp;utm_medium=navbar&amp;utm_campaign=forum%20CTA">Forum</a></li>
        <li><a class="blog-nav nav-link" href="http://blog.ionic.io/?utm_source=framework&amp;utm_medium=navbar&amp;utm_campaign=blog%20CTA">Blog <span id="blog-badge" style="display: block;">1</span></a></li>
        <li><a class="products-nav nav-link" href="http://ionic.io/?utm_source=framework&amp;utm_medium=navbar&amp;utm_campaign=platform%20CTA">Platform</a></li>
        <li><a class="examples-nav nav-link" href="http://ionic.io/enterprise?utm_source=framework&amp;utm_medium=navbar&amp;utm_campaign=enterprise%20CTA">Enterprise</a></li>
        <li class="dropdown">
          <a href="http://ionicframework.com/docs/api/directive/ionTabs/#" class="dropdown-toggle nav-link " data-toggle="dropdown" role="button" aria-expanded="false">More <span class="caret"></span></a>
          <ul class="dropdown-menu" role="menu">
            <div class="arrow-up"></div>
            <li><a class="examples-nav nav-link" href="http://showcase.ionicframework.com/">Showcase</a></li>
            <li><a class="nav-link" href="http://jobs.ionic.io/">Job Board</a></li>
            <li><a class="nav-link" href="http://market.ionic.io/">Market</a></li>
            <li><a class="nav-link" href="http://ionicworldwide.herokuapp.com/">Ionic Worldwide</a></li>
            <li><a class="nav-link" href="http://play.ionic.io/">Playground</a></li>
            <li><a class="nav-link" href="http://creator.ionic.io/">Creator</a></li>
            <li><a class="nav-link" href="http://shop.ionic.io/">Shop</a></li>
            <!--<li><a class="nav-link" href="http://ngcordova.com/">ngCordova</a></li>-->
          </ul>
        </li>
      </ul>
    </div>
  </div>
</nav>


    <div class="header horizontal-gradient">
      <div class="container">
        <h3>ion-tabs</h3>
        <h4>Directive in module ionic</h4>
      </div>
      <div class="news">
        <div class="container">
          <div class="row">
            <div class="col-sm-8 news-col">
              <div class="picker">
                <select onchange="window.location.href=this.options[this.selectedIndex].value">

  <option value="/docs/nightly/api/directive/ionTabs/">
    nightly 
  </option>

  <option value="/docs/api/directive/ionTabs/" selected="">
    1.3.1 (latest)
  </option>

  <option value="/docs/1.3.0/api/directive/ionTabs/">
    1.3.0 
  </option>

  <option value="/docs/1.2.1/api/directive/ionTabs/">
    1.2.1 
  </option>

  <option value="/docs/1.2.0/api/directive/ionTabs/">
    1.2.0 
  </option>

  <option value="/docs/1.1.1/api/directive/ionTabs/">
    1.1.1 
  </option>

  <option value="/docs/1.1.0/api/directive/ionTabs/">
    1.1.0 
  </option>

  <option value="/docs/1.0.1/api/directive/ionTabs/">
    1.0.1 
  </option>

  <option value="/docs/1.0.0/api/directive/ionTabs/">
    1.0.0 
  </option>

  <option value="/docs/1.0.0-rc.5/api/directive/ionTabs/">
    1.0.0-rc.5 
  </option>

  <option value="/docs/1.0.0-rc.4/api/directive/ionTabs/">
    1.0.0-rc.4 
  </option>

  <option value="/docs/1.0.0-rc.3/api/directive/ionTabs/">
    1.0.0-rc.3 
  </option>

  <option value="/docs/1.0.0-rc.2/api/directive/ionTabs/">
    1.0.0-rc.2 
  </option>

  <option value="/docs/1.0.0-rc.1/api/directive/ionTabs/">
    1.0.0-rc.1 
  </option>

  <option value="/docs/1.0.0-rc.0/api/directive/ionTabs/">
    1.0.0-rc.0 
  </option>

  <option value="/docs/1.0.0-beta.14/api/directive/ionTabs/">
    1.0.0-beta.14 
  </option>

  <option value="/docs/1.0.0-beta.13/api/directive/ionTabs/">
    1.0.0-beta.13 
  </option>

  <option value="/docs/1.0.0-beta.12/api/directive/ionTabs/">
    1.0.0-beta.12 
  </option>

  <option value="/docs/1.0.0-beta.11/api/directive/ionTabs/">
    1.0.0-beta.11 
  </option>

  <option value="/docs/1.0.0-beta.10/api/directive/ionTabs/">
    1.0.0-beta.10 
  </option>

</select>



              </div>
            </div>
            <div class="col-sm-4 search-col">
              <div class="search-bar" style="visibility: visible;">
  <span class="search-icon ionic"><i class="ion-ios7-search-strong"></i></span>
  <input type="search" id="search-input" value="Search">
</div>

            </div>
          </div>
        </div>
      </div>
    </div>

    <div id="search-results" class="search-results" style="display:none">
  <div class="container">
    <div class="search-section search-api">
      <h4>JavaScript</h4>
      <ul id="results-api"></ul>
    </div>
    <div class="search-section search-css">
      <h4>CSS</h4>
      <ul id="results-css"></ul>
    </div>
    <div class="search-section search-content">
      <h4>Resources</h4>
      <ul id="results-content"></ul>
    </div>
  </div>
</div>


    <div class="container content-container">

      <div class="row">

        <div class="col-md-2 col-sm-3 aside-menu">

          <div>

            <ul class="nav left-menu">
              <li class="menu-title">
                <a href="http://ionicframework.com/docs/overview/">Overview</a>
              </li>
            </ul>

            <ul class="nav left-menu">
              <li class="menu-title">
                <a href="http://ionicframework.com/docs/components/">CSS Components</a>
              </li>
            </ul>

            <ul class="nav left-menu">
              <li class="menu-title">
                <a href="http://ionicframework.com/docs/platform-customization/">Platform Customization</a>
              </li>
            </ul>

            <!-- Docs: JavaScript -->
            <ul class="nav left-menu active-menu">
              <li class="menu-title">
                <a href="http://ionicframework.com/docs/api/">
                  JavaScript
                </a>
              </li>
              
  
    

  


  <!-- Action Sheet -->
  <li class="menu-section">
    <a href="http://ionicframework.com/docs/api/service/$ionicActionSheet/" class="api-section">
       Action Sheet
    </a>
    <ul>
      <li>
        <a href="http://ionicframework.com/docs/api/service/$ionicActionSheet/">
          $ionicActionSheet
        </a>
      </li>
    </ul>
  </li>


  <!-- Backdrop -->
  <li class="menu-section">
    <a href="http://ionicframework.com/docs/api/service/$ionicBackdrop/" class="api-section">
      Backdrop
    </a>
    <ul>
      <li>
        <a href="http://ionicframework.com/docs/api/service/$ionicBackdrop/">
          $ionicBackdrop
        </a>
      </li>
    </ul>
  </li>


  <!-- Content -->
  <li class="menu-section">
    <a href="http://ionicframework.com/docs/api/directive/ionContent/" class="api-section">
       Content
    </a>
    <ul>
      <li>
        <a href="http://ionicframework.com/docs/api/directive/ionContent/">
           ion-content
        </a>
      </li>

      <li>
        <a href="http://ionicframework.com/docs/api/directive/ionRefresher/">
           ion-refresher
        </a>
      </li>

      <li>
        <a href="http://ionicframework.com/docs/api/directive/ionPane/">
           ion-pane
        </a>
      </li>
    </ul>
  </li>


  <!-- Form Inputs -->
  <li class="menu-section">
    <a href="http://ionicframework.com/docs/api/directive/ionCheckbox/" class="api-section">
       Form Inputs
    </a>
    <ul>
      <li>
        <a href="http://ionicframework.com/docs/api/directive/ionCheckbox/">
           ion-checkbox
        </a>
      </li>

      <li>
        <a href="http://ionicframework.com/docs/api/directive/ionRadio/">
           ion-radio
        </a>
      </li>

      <li>
        <a href="http://ionicframework.com/docs/api/directive/ionToggle/">
           ion-toggle
        </a>
      </li>

    </ul>
  </li>


  <!-- Gesture and Events -->
  <li class="menu-section">
    <a href="http://ionicframework.com/docs/api/directive/onHold/" class="api-section">
      Gestures and Events
    </a>
    <ul>
      <li>
        <a href="http://ionicframework.com/docs/api/directive/onHold/">
          on-hold
        </a>
      </li>
      <li>
        <a href="http://ionicframework.com/docs/api/directive/onTap/">
          on-tap
        </a>
      </li>
      <li>
        <a href="http://ionicframework.com/docs/api/directive/onDoubleTap/">
          on-double-tap
        </a>
      </li>
      <li>
        <a href="http://ionicframework.com/docs/api/directive/onTouch/">
          on-touch
        </a>
      </li>
      <li>
        <a href="http://ionicframework.com/docs/api/directive/onRelease/">
          on-release
        </a>
      </li>
      <li>
        <a href="http://ionicframework.com/docs/api/directive/onDrag/">
          on-drag
        </a>
      </li>
      <li>
        <a href="http://ionicframework.com/docs/api/directive/onDragUp/">
          on-drag-up
        </a>
      </li>
      <li>
        <a href="http://ionicframework.com/docs/api/directive/onDragRight/">
          on-drag-right
        </a>
      </li>
      <li>
        <a href="http://ionicframework.com/docs/api/directive/onDragDown/">
          on-drag-down
        </a>
      </li>
      <li>
        <a href="http://ionicframework.com/docs/api/directive/onDragLeft/">
          on-drag-left
        </a>
      </li>
      <li>
        <a href="http://ionicframework.com/docs/api/directive/onSwipe/">
          on-swipe
        </a>
      </li>
      <li>
        <a href="http://ionicframework.com/docs/api/directive/onSwipeUp/">
          on-swipe-up
        </a>
      </li>
      <li>
        <a href="http://ionicframework.com/docs/api/directive/onSwipeRight/">
          on-swipe-right
        </a>
      </li>
      <li>
        <a href="http://ionicframework.com/docs/api/directive/onSwipeDown/">
          on-swipe-down
        </a>
      </li>
      <li>
        <a href="http://ionicframework.com/docs/api/directive/onSwipeLeft/">
          on-swipe-left
        </a>
      </li>
      <li>
        <a href="http://ionicframework.com/docs/api/service/$ionicGesture/">
          $ionicGesture
        </a>
      </li>
    </ul>
  </li>


  <!-- Headers/Footers -->
  <li class="menu-section">
    <a href="http://ionicframework.com/docs/api/directive/ionHeaderBar/" class="api-section">
       Headers/Footers
    </a>
    <ul>
      <li>
        <a href="http://ionicframework.com/docs/api/directive/ionHeaderBar/">
           ion-header-bar
        </a>
      </li>

      <li>
        <a href="http://ionicframework.com/docs/api/directive/ionFooterBar/">
           ion-footer-bar
        </a>
      </li>
    </ul>
  </li>


  <!-- Keyboard -->
  <li class="menu-section">
    <a href="http://ionicframework.com/docs/api/page/keyboard/" class="api-section">
      Keyboard
    </a>
    <ul>
      <li>
        <a href="http://ionicframework.com/docs/api/page/keyboard/">
          Keyboard
        </a>
      </li>
      <li>
        <a href="http://ionicframework.com/docs/api/directive/keyboardAttach/">
          keyboard-attach
        </a>
      </li>
    </ul>
  </li>


  <!-- Lists -->
  <li class="menu-section">
    <a href="http://ionicframework.com/docs/api/directive/ionList/" class="api-section">
       Lists
    </a>
    <ul>
      <li>
        <a href="http://ionicframework.com/docs/api/directive/ionList/">
           ion-list
        </a>
      </li>

      <li>
        <a href="http://ionicframework.com/docs/api/directive/ionItem/">
           ion-item
        </a>
      </li>

      <li>
        <a href="http://ionicframework.com/docs/api/directive/ionDeleteButton/">
           ion-delete-button
        </a>
      </li>

      <li>
        <a href="http://ionicframework.com/docs/api/directive/ionReorderButton/">
           ion-reorder-button
        </a>
      </li>

      <li>
        <a href="http://ionicframework.com/docs/api/directive/ionOptionButton/">
           ion-option-button
        </a>
      </li>

      <li>
        <a href="http://ionicframework.com/docs/api/directive/collectionRepeat/">
          collection-repeat
        </a>
      </li>

      <li>
        <a href="http://ionicframework.com/docs/api/service/$ionicListDelegate/">
           $ionicListDelegate
        </a>
      </li>
    </ul>
  </li>


  <!-- Loading -->
  <li class="menu-section">
    <a href="http://ionicframework.com/docs/api/service/$ionicLoading/" class="api-section">
      Loading
    </a>
    <ul>
      <li>
        <a href="http://ionicframework.com/docs/api/service/$ionicLoading/">
          $ionicLoading
        </a>
      </li>
    </ul>
    <ul>
      <li>
        <a href="http://ionicframework.com/docs/api/object/$ionicLoadingConfig/">
          $ionicLoadingConfig
        </a>
      </li>
    </ul>
  </li>


  <!-- Modal -->
  <li class="menu-section">
    <a href="http://ionicframework.com/docs/api/service/$ionicModal/" class="api-section">
       Modal
    </a>
    <ul>
      <li>
        <a href="http://ionicframework.com/docs/api/service/$ionicModal/">
          $ionicModal
        </a>
      </li>

      <li>
        <a href="http://ionicframework.com/docs/api/controller/ionicModal/">
          ionicModal
        </a>
      </li>
    </ul>
  </li>


  <!-- Navigation -->
  <li class="menu-section">
    <a href="http://ionicframework.com/docs/api/directive/ionNavView/" class="api-section">
       Navigation
    </a>
    <ul>
      <li>
        <a href="http://ionicframework.com/docs/api/directive/ionNavView/">
           ion-nav-view
        </a>
      </li>

      <li>
        <a href="http://ionicframework.com/docs/api/directive/ionView/">
           ion-view
        </a>
      </li>

      <li>
        <a href="http://ionicframework.com/docs/api/directive/ionNavBar/">
           ion-nav-bar
        </a>
      </li>

      <li>
        <a href="http://ionicframework.com/docs/api/directive/ionNavBackButton/">
           ion-nav-back-button
        </a>
      </li>

      <li>
        <a href="http://ionicframework.com/docs/api/directive/ionNavButtons/">
           ion-nav-buttons
        </a>
      </li>

      <li>
        <a href="http://ionicframework.com/docs/api/directive/ionNavTitle/">
           ion-nav-title
        </a>
      </li>

      <li>
        <a href="http://ionicframework.com/docs/api/directive/navTransition/">
           nav-transition
        </a>
      </li>

      <li>
        <a href="http://ionicframework.com/docs/api/directive/navDirection/">
           nav-direction
        </a>
      </li>

      <li>
        <a href="http://ionicframework.com/docs/api/service/$ionicNavBarDelegate/">
          $ionicNavBarDelegate
        </a>
      </li>

      <li>
        <a href="http://ionicframework.com/docs/api/service/$ionicHistory/">
          $ionicHistory
        </a>
      </li>
    </ul>
  </li>


  <!-- Platform -->
  <li class="menu-section">
    <a href="http://ionicframework.com/docs/api/service/$ionicPlatform/" class="api-section">
      Platform
    </a>
    <ul>
      <li>
        <a href="http://ionicframework.com/docs/api/service/$ionicPlatform/">
          $ionicPlatform
        </a>
      </li>
    </ul>
  </li>


  <!-- Popover -->
  <li class="menu-section">
    <a href="http://ionicframework.com/docs/api/service/$ionicPopover/" class="api-section">
       Popover
    </a>
    <ul>
      <li>
        <a href="http://ionicframework.com/docs/api/service/$ionicPopover/">
          $ionicPopover
        </a>
      </li>

      <li>
        <a href="http://ionicframework.com/docs/api/controller/ionicPopover/">
          ionicPopover
        </a>
      </li>
    </ul>
  </li>


  <!-- Popup -->
  <li class="menu-section">
    <a href="http://ionicframework.com/docs/api/service/$ionicPopup/" class="api-section">
       Popup
    </a>
    <ul>
      <li>
        <a href="http://ionicframework.com/docs/api/service/$ionicPopup/">
          $ionicPopup
        </a>
      </li>
    </ul>
  </li>


  <!-- Scroll -->
  <li class="menu-section">
    <a href="http://ionicframework.com/docs/api/directive/ionScroll/" class="api-section">
       Scroll
    </a>
    <ul>
      <li>
        <a href="http://ionicframework.com/docs/api/directive/ionScroll/">
           ion-scroll
        </a>
      </li>

      <li>
        <a href="http://ionicframework.com/docs/api/directive/ionInfiniteScroll/">
           ion-infinite-scroll
        </a>
      </li>

      <li>
        <a href="http://ionicframework.com/docs/api/service/$ionicScrollDelegate/">
          $ionicScrollDelegate
        </a>
      </li>
    </ul>
  </li>


  <!-- Side Menus -->
  <li class="menu-section">
    <a href="http://ionicframework.com/docs/api/directive/ionSideMenus/" class="api-section">
       Side Menus
    </a>
    <ul>
      <li>
        <a href="http://ionicframework.com/docs/api/directive/ionSideMenus/">
           ion-side-menus
        </a>
      </li>

      <li>
        <a href="http://ionicframework.com/docs/api/directive/ionSideMenuContent/">
           ion-side-menu-content
        </a>
      </li>

      <li>
        <a href="http://ionicframework.com/docs/api/directive/ionSideMenu/">
           ion-side-menu
        </a>
      </li>

      <li>
        <a href="http://ionicframework.com/docs/api/directive/exposeAsideWhen/">
           expose-aside-when
        </a>
      </li>

      <li>
        <a href="http://ionicframework.com/docs/api/directive/menuToggle/">
           menu-toggle
        </a>
      </li>

      <li>
        <a href="http://ionicframework.com/docs/api/directive/menuClose/">
           menu-close
        </a>
      </li>

      <li>
        <a href="http://ionicframework.com/docs/api/service/$ionicSideMenuDelegate/">
          $ionicSideMenuDelegate
        </a>
      </li>
    </ul>
  </li>


  <!-- Slide Box -->
  <li class="menu-section">
    <a href="http://ionicframework.com/docs/api/directive/ionSlideBox/" class="api-section">
       Slide Box
    </a>
    <ul>
      <li>
        <a href="http://ionicframework.com/docs/api/directive/ionSlides/">
           ion-slides
        </a>
      </li>
      <li>
        <a href="http://ionicframework.com/docs/api/directive/ionSlideBox/">
           ion-slide-box
        </a>
      </li>

      <li>
        <a href="http://ionicframework.com/docs/api/directive/ionSlide/">
           ion-slide
        </a>
      </li>

      <li>
        <a href="http://ionicframework.com/docs/api/service/$ionicSlideBoxDelegate/">
          $ionicSlideBoxDelegate
        </a>
      </li>
    </ul>
  </li>


  <!-- Spinner -->
  <li class="menu-section">
    <a href="http://ionicframework.com/docs/api/directive/ionSpinner/" class="api-section">
      Spinner
    </a>
    <ul>
      <li>
        <a href="http://ionicframework.com/docs/api/directive/ionSpinner/">
          ion-spinner
        </a>
      </li>
    </ul>
  </li>


  <!-- Tabs -->
  <li class="menu-section active">
    <a href="http://ionicframework.com/docs/api/directive/ionTabs/" class="api-section">
       Tabs
    </a>
    <ul>
      <li class="active">
        <a href="http://ionicframework.com/docs/api/directive/ionTabs/">
           ion-tabs
        </a>
      </li>

      <li>
        <a href="http://ionicframework.com/docs/api/directive/ionTab/">
           ion-tab
        </a>
      </li>

      <li>
        <a href="http://ionicframework.com/docs/api/service/$ionicTabsDelegate/">
          $ionicTabsDelegate
        </a>
      </li>
    </ul>
  </li>


  <!-- Tap -->
  <li class="menu-section">
    <a href="http://ionicframework.com/docs/api/page/tap/" class="api-section">
      Tap &amp; Click
    </a>
  </li>


  <!-- Utility -->
  <li class="menu-section">
    <a href="http://ionicframework.com/docs/api/directive/ionTabs/#" class="api-section">
      Utility
    </a>
    <ul>
      <li>
        <a href="http://ionicframework.com/docs/api/provider/$ionicConfigProvider/">
          $ionicConfigProvider
        </a>
      </li>
      <li>
        <a href="http://ionicframework.com/docs/api/utility/ionic.Platform/">
          ionic.Platform
        </a>
      </li>

      <li>
        <a href="http://ionicframework.com/docs/api/utility/ionic.DomUtil/">
          ionic.DomUtil
        </a>
      </li>

      <li>
        <a href="http://ionicframework.com/docs/api/utility/ionic.EventController/">
          ionic.EventController
        </a>
      </li>
      <li>
        <a href="http://ionicframework.com/docs/api/service/$ionicPosition/">
          $ionicPosition
        </a>
      </li>
    </ul>
  </li>



            </ul>

            <ul class="nav left-menu">
              <li class="menu-title">
                <a href="http://ionicframework.com/docs/cli/">CLI</a>
              </li>
            </ul>

            <ul class="nav left-menu">
              <li class="menu-title">
                <a href="http://ionicframework.com/docs/guide/">Guide</a>
              </li>
            </ul>
            <ul class="nav left-menu">
              <li class="menu-title">
                <a href="http://ionicframework.com/docs/ionic-cli-faq/">FAQ</a>
              </li>
            </ul>
            <ul class="nav left-menu">
              <li class="menu-title">
                <a href="http://ionicframework.com/docs/getting-help/">Getting Help</a>
              </li>
            </ul>

            <ul class="nav left-menu">
              <li class="menu-title">
                <a href="http://ionicframework.com/docs/concepts/">Ionic Concepts</a>
              </li>
            </ul>
          </div>

        </div>

        <div class="col-md-10 col-sm-9 main-content">
          <div class="improve-docs">
<a href="http://github.com/driftyco/ionic/tree/master/js/angular/directive/tabs.js#L1">
View Source
</a>
&nbsp;
<a href="http://github.com/driftyco/ionic/edit/master/js/angular/directive/tabs.js#L1">
Improve this doc
</a>
</div>

<h1 class="api-title">

ion-tabs



<br>
<small>
Delegate: <a href="http://ionicframework.com/docs/api/service/$ionicTabsDelegate/"><code>$ionicTabsDelegate</code></a>
</small>

</h1>

<div class="phone-case">
  <div><iframe id="cp_embed_odqCz" src="./main123_files/odqCz.html" scrolling="no" frameborder="0" height="568" allowtransparency="true" allowfullscreen="true" name="CodePen Embed" title="CodePen Embed" class="cp_embed_iframe " style="width: 100%; overflow: hidden;"></iframe></div>
  <script async="" src="./main123_files/ei.js"></script>
 </div>

<p>Powers a multi-tabbed interface with a Tab Bar and a set of “pages” that can be tabbed
through.</p>

<p>Assign any <a href="http://ionicframework.com/docs/components#tabs">tabs class</a> to the element to define
its look and feel.</p>

<p>For iOS, tabs will appear at the bottom of the screen. For Android, tabs will be at the top
of the screen, below the nav-bar. This follows each OS’s design specification, but can be
configured with the <a href="http://ionicframework.com/docs/api/provider/$ionicConfigProvider/"><code>$ionicConfigProvider</code></a>.</p>

<p>See the <a href="http://ionicframework.com/docs/api/directive/ionTab/"><code>ionTab</code></a> directive’s documentation for more details on
individual tabs.</p>

<p>Note: do not place ion-tabs inside of an ion-content element; it has been known to cause a
certain CSS bug.</p>

<h2 id="usage">Usage</h2>

<div class="language-html highlighter-rouge"><pre class="highlight"><code><span class="nt">&lt;ion-tabs</span> <span class="na">class=</span><span class="s">"tabs-positive tabs-icon-top"</span><span class="nt">&gt;</span>

  <span class="nt">&lt;ion-tab</span> <span class="na">title=</span><span class="s">"Home"</span> <span class="na">icon-on=</span><span class="s">"ion-ios-filing"</span> <span class="na">icon-off=</span><span class="s">"ion-ios-filing-outline"</span><span class="nt">&gt;</span>
    <span class="c">&lt;!-- Tab 1 content --&gt;</span>
  <span class="nt">&lt;/ion-tab&gt;</span>

  <span class="nt">&lt;ion-tab</span> <span class="na">title=</span><span class="s">"About"</span> <span class="na">icon-on=</span><span class="s">"ion-ios-clock"</span> <span class="na">icon-off=</span><span class="s">"ion-ios-clock-outline"</span><span class="nt">&gt;</span>
    <span class="c">&lt;!-- Tab 2 content --&gt;</span>
  <span class="nt">&lt;/ion-tab&gt;</span>

  <span class="nt">&lt;ion-tab</span> <span class="na">title=</span><span class="s">"Settings"</span> <span class="na">icon-on=</span><span class="s">"ion-ios-gear"</span> <span class="na">icon-off=</span><span class="s">"ion-ios-gear-outline"</span><span class="nt">&gt;</span>
    <span class="c">&lt;!-- Tab 3 content --&gt;</span>
  <span class="nt">&lt;/ion-tab&gt;</span>

<span class="nt">&lt;/ion-tabs&gt;</span>
</code></pre>
</div>

<h2 id="api" style="clear:both;">API</h2>

<table class="table" style="margin:0;">
  <thead>
    <tr>
      <th>Attr</th>
      <th>Type</th>
      <th>Details</th>
    </tr>
  </thead>
  <tbody>
    
    <tr>
      <td>
        delegate-handle
        
        <div><em>(optional)</em></div>
      </td>
      <td>
        
  <code>string</code>
      </td>
      <td>
        <p>The handle used to identify these tabs
with <a href="http://ionicframework.com/docs/api/service/$ionicTabsDelegate/"><code>$ionicTabsDelegate</code></a>.</p>

        
      </td>
    </tr>
    
  </tbody>
</table>


        </div>

      </div>

    </div>

    <div class="pre-footer">

      <div class="row ionic">

        <div class="col-sm-6 col-a">
          <h4>
            <a href="http://ionicframework.com/getting-started/">Getting started <span class="icon ion-arrow-right-c"></span></a>
          </h4>
          <p>
            Learn more about how Ionic was built, why you should use it, and what's included. We'll cover
            the basics and help you get started from the ground up.
          </p>
        </div>

        <div class="col-sm-6 col-b">
          <h4>
            <a href="http://ionicframework.com/docs/">Documentation <span class="icon ion-arrow-right-c"></span></a>
          </h4>
          <p>
            What are you waiting for? Take a look and get coding! Our documentation covers all you need to know
            to get an app up and running in minutes.
          </p>
        </div>

      </div>

    </div>

    <footer class="footer">

  <nav class="base-links">

    <dl>
      <dt>Docs</dt>
      <dd><a href="http://ionicframework.com/docs/">Documentation</a></dd>
      <dd><a href="http://ionicframework.com/getting-started/">Getting Started</a></dd>
      <dd><a href="http://ionicframework.com/docs/overview/">Overview</a></dd>
      <dd><a href="http://ionicframework.com/docs/components/">CSS Components</a></dd>
      <dd><a href="http://ionicframework.com/docs/api/">JavaScript</a></dd>
      <dd><a href="http://ionicframework.com/submit-issue/">Submit Issue</a></dd>
    </dl>

    <dl>
      <dt>Resources</dt>
      <dd><a href="http://ngcordova.com/">ngCordova</a></dd>
      <dd><a href="http://ionicons.com/">Ionicons</a></dd>
      <dd><a href="http://view.ionic.io/">View</a></dd>
      <dd><a href="http://creator.ionic.io/">Creator</a></dd>
      <dd><a href="http://showcase.ionicframework.com/">Showcase</a></dd>
      <dd><a href="http://manning.com/wilken/?a_aid=ionicinactionben&amp;a_bid=1f0a0e1d">The Ionic Book</a></dd>
    </dl>

    <dl>
      <dt>Contribute</dt>
      <dd><a href="http://forum.ionicframework.com/">Community Forum</a></dd>
      <dd><a href="http://webchat.freenode.net/?randomnick=1&amp;channels=%23ionic&amp;uio=d4">Ionic IRC</a></dd>
      <dd><a href="http://ionicframework.com/present-ionic/">Present Ionic</a></dd>
      <dd><a href="http://ionicframework.com/contribute/">Contribute</a></dd>
      <dd><a href="https://github.com/driftyco/ionic-learn/issues/new">Write for us</a></dd>
      <dd><a href="http://shop.ionic.io/">Ionic Shop</a></dd>
    </dl>

    <dl class="small-break">
      <dt>About</dt>
      <dd><a href="http://blog.ionic.io/">Blog</a></dd>
      <dd><a href="http://ionic.io/platform">Services</a></dd>
      <dd><a href="http://ionic.io/about">Company</a></dd>
      <dd><a href="https://s3.amazonaws.com/ionicframework.com/logo-pack.zip">Logo Pack</a></dd>
      <dd><a href="http://ionic.io/discover">Discover</a></dd>
      <dd><a href="http://ionic.io/jobs">Jobs</a></dd>
    </dl>

    <dl>
      <dt>Connect</dt>
      <dd><a href="https://twitter.com/IonicFramework">Twitter</a></dd>
      <dd><a href="https://github.com/driftyco/ionic">GitHub</a></dd>
      <dd><a href="https://www.facebook.com/ionicframework">Facebook</a></dd>
      <dd><a href="https://plus.google.com/b/112280728135675018538/+Ionicframework/posts">Google+</a></dd>
      <dd><a href="https://www.youtube.com/channel/UChYheBnVeCfhCmqZfCUdJQw">YouTube</a></dd>
      <dd><a href="http://ionicworldwide.herokuapp.com/">Slack</a></dd>
    </dl>

  </nav>

  <div class="newsletter row">

    <div class="newsletter-container">

      <div class="col-sm-7">
        <div class="newsletter-text">Stay in the loop</div>
        <div class="sign-up">Sign up to receive emails for the latest updates, features, and news on the framework.</div>
      </div>

      <form action="http://codiqa.createsend.com/t/t/s/jytylh/" method="post" class="input-group col-sm-5">
        <input id="fieldEmail" name="cm-jytylh-jytylh" class="form-control" type="email" placeholder="Email" required="">
        <span class="input-group-btn">
          <button class="btn btn-default" type="submit">Subscribe</button>
        </span>
      </form>

    </div>

  </div>

  <div class="copy">
    <div class="copy-container">
      <p class="authors">
        Code licensed under <a href="https://github.com/driftyco/ionic/blob/master/LICENSE">MIT</a>.
        Docs under <a href="https://tldrlegal.com/license/apache-license-2.0-(apache-2.0)">Apache 2</a>
        <span>|</span>
        © 2013-2016 <a href="http://ionic.io/about">Drifty Co</a>
      </p>
    </div>
  </div>

</footer>

<script type="text/javascript">
  var _sf_async_config = { uid: 54141, domain: 'ionicframework.com', useCanonical: true };
  (function() {
    function loadChartbeat() {
      window._sf_endpt = (new Date()).getTime();
      var e = document.createElement('script');
      e.setAttribute('language', 'javascript');
      e.setAttribute('type', 'text/javascript');
      e.setAttribute('src','//static.chartbeat.com/js/chartbeat.js');
      document.body.appendChild(e);
    };
    var oldonload = window.onload;
    window.onload = (typeof window.onload != 'function') ?
      loadChartbeat : function() { oldonload(); loadChartbeat(); };
  })();
</script>


    <script src="./main123_files/bootstrap.min.js"></script>
<script src="./main123_files/site.js"></script>

<script src="./main123_files/cookies.min.js"></script>

<script>

  $('.navbar .dropdown').on('show.bs.dropdown', function(e){
    //$(this).find('.dropdown-menu').addClass('animated fadeInDown');
  });

  // ADD SLIDEUP ANIMATION TO DROPDOWN //
  $('.navbar .dropdown').on('hide.bs.dropdown', function(e){
    //$(this).find('.dropdown-menu').first().stop(true, true).slideUp(200);
    //$(this).find('.dropdown-menu').removeClass('animated fadeInDown');
  });


try {
  var d = new Date('');
  var ts = d.getTime();

  var cd = Cookies.get('_iondj');
  if(cd) {
    cd = JSON.parse(atob(cd));
    if(parseInt(cd.lp) < ts) {
      var bt = document.getElementById('blog-badge');
      bt.style.display = 'block';
    }

    cd.lp = ts;
  } else {
    var bt = document.getElementById('blog-badge');
    bt.style.display = 'block';
    cd = {
      lp: ts
    }
  }

  Cookies.set('_iondj', btoa(JSON.stringify(cd)));
} catch(e) {
}
</script>

<div id="fb-root" class=" fb_reset"><div style="position: absolute; top: -10000px; height: 0px; width: 0px;"><div></div></div><div style="position: absolute; top: -10000px; height: 0px; width: 0px;"><div><iframe name="fb_xdm_frame_http" frameborder="0" allowtransparency="true" allowfullscreen="true" scrolling="no" id="fb_xdm_frame_http" aria-hidden="true" title="Facebook Cross Domain Communication Frame" tabindex="-1" src="./main123_files/xd_arbiter.html" style="border: none;"></iframe><iframe name="fb_xdm_frame_https" frameborder="0" allowtransparency="true" allowfullscreen="true" scrolling="no" id="fb_xdm_frame_https" aria-hidden="true" title="Facebook Cross Domain Communication Frame" tabindex="-1" src="./main123_files/xd_arbiter(1).html" style="border: none;"></iframe></div></div></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_US/all.js#xfbml=1";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>


  

<iframe id="rufous-sandbox" scrolling="no" frameborder="0" allowtransparency="true" allowfullscreen="true" style="position: absolute; visibility: hidden; display: none; width: 0px; height: 0px; padding: 0px; border: none;" src="./main123_files/saved_resource.html"></iframe><script language="javascript" type="text/javascript" src="./main123_files/chartbeat.js"></script></body></html>